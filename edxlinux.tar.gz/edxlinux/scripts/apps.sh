#!/bin/bash

echo "monstrar a architetura"
uname -i
# Instala gdown se não estiver instalado
if ! command -v gdown &> /dev/null
then
    echo "gdown não está instalado. Instalando..."
    pip install gdown
fi

# Cria um diretório temporário para os downloads
TEMP_DIR=$(mktemp -d)
echo "Diretório temporário criado em: $TEMP_DIR"

# IDs dos arquivos do Google Drive (substitua pelos IDs dos seus arquivos .deb)
FILE_IDS=("1d_By8w-CjUuzgxOqjsHkYWQBT-qtkWDj")

# Baixa e instala cada arquivo .deb
for FILE_ID in "${FILE_IDS[@]}"
do
    echo "Baixando arquivo com ID: $FILE_ID"
    gdown --id $FILE_ID -O $TEMP_DIR

    DEB_FILE=$(ls $TEMP_DIR/*.deb)
    echo "Instalando pacote: $DEB_FILE"
    sudo dpkg -i $DEB_FILE

    # Resolve dependências que possam estar faltando
    sudo apt-get install -f -y
done

# Limpa o diretório temporário
rm -rf $TEMP_DIR
echo "Pacotes instalados e diretório temporário removido."

