#/bin/bash


sudo apt-add-repository ppa:cubic-wizard/release -y

sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys 6494C6D6997C215E -y

sudo apt-get update -y 

sudo apt-get install cubic -y


apt install virtualbox -y


apt install timeshift -y


echo "faça um bom uso"
echo "a equipe foston linux e edxlinux agradecem" 
