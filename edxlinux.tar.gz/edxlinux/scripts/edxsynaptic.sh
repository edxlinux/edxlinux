#!/bin/bash
# Script para abrir o Synaptic Package Manager

# Verifica se o usuário é root
if [ "$(id -u)" -ne 0 ]; then
  echo "Este script precisa ser executado como root."
  exit 1
fi

# Abre o Synaptic Package Manager
synaptic