#!/bin/bash
# Script para imprimir a mensagem no terminal
echo "estou fazendo uma satira ou uma piada" 
echo "agora vai agora vai vai todo mundo pro anchieta"
echo "a equipe foston linux e edxlinux agradecem"
