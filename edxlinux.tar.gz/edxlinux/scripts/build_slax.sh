#!/bin/bash

# Variáveis
WORKDIR="$HOME/slax-build"
SLAX_URL="https://www.slax.org/Slax-11.x.x-x86_64.iso" # Atualize a URL conforme necessário
SLAX_ISO="$WORKDIR/slax.iso"
SLAX_DIR="$WORKDIR/slax"
SQUASHFS_DIR="$WORKDIR/squashfs-root"
CUSTOM_DIR="$WORKDIR/custom-slax"
NEW_ISO="$WORKDIR/custom-slax.iso"

# Preparação do ambiente de construção
mkdir -p "$WORKDIR"
cd "$WORKDIR"

# Baixar o Slax
echo "Baixando o Slax..."
wget -O "$SLAX_ISO" "$SLAX_URL"

# Extrair o conteúdo do ISO
echo "Extraindo o ISO do Slax..."
7z x "$SLAX_ISO" -o"$SLAX_DIR"

# Montar a imagem SquashFS
echo "Montando a imagem SquashFS..."
mkdir -p "$SQUASHFS_DIR"
sudo unsquashfs -f -d "$SQUASHFS_DIR" "$SLAX_DIR/slax/root.sqfs"

# Personalizar o sistema de arquivos
echo "Personalizando o sistema de arquivos..."
mkdir -p "$CUSTOM_DIR"
cp -r "$SQUASHFS_DIR"/* "$CUSTOM_DIR"

# Exemplo: adicionar um arquivo personalizado
echo "Adicionando arquivos personalizados..."
echo "Bem-vindo ao Slax personalizado!" > "$CUSTOM_DIR/welcome.txt"

# Recriar a imagem SquashFS
echo "Recriando a imagem SquashFS..."
sudo mksquashfs "$CUSTOM_DIR" "$SLAX_DIR/slax/root.sqfs" -comp xz -e boot

# Gerar a nova imagem ISO
echo "Gerando a nova imagem ISO..."
genisoimage -o "$NEW_ISO" -b boot/isolinux/isolinux.bin -c boot/isolinux/boot.cat -no-emul-boot -boot-load-size 4 -boot-info-table -J -R -V "Custom Slax" "$SLAX_DIR"

echo "A nova imagem ISO foi criada em: $NEW_ISO"
