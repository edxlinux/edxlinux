#!/bin/bash

# Diretórios de trabalho
WORK_DIR="/tmp/edxlinux_fostonlinux_update"
mkdir -p $WORK_DIR

# URLs dos pacotes e scripts
URLS=(
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/159363-deepin-plymouth_1.0_all.deb?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/1oom_1.0-2.debian.tar.xz?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/1oom_1.0-2_amd64.deb?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/install_update.sh?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/caja-dropbox_1.20.0-2_i386.deb?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/cubic_2024.02-86-release~202402210133~ubuntu24.04.1_all.deb?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/cubicscript.sh?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/debmirror_1%253a2.27ubuntu1_all.deb?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/Systemback_Install_Pack_v1.8.402.tar.xz?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/libgc1c2_1%253a7.4.2-8ubuntu1_i386.deb?raw=true"
    "https://github.com/oliveiraezequiel/fostonlinux-e-edxlinux/blob/main/ubuntu-archive-keyring.gpg?raw=true"
    "https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/dde-desktop_4.4.8.5-1.2_i386.deb?raw=true"
    "https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/dde-file-manager_4.4.8.5-1.2_i386.deb?raw=true"
    "https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/deepin-desktop-schemas_3.2.10-1_i386.deb?raw=true"
    "https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/icewm.md.tar.xz?raw=true"
    "https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/frozen-bubble_2.212-8build2_i386.deb?raw=true"
    #https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/install_recycli.sh?raw=true"
    #https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/zsnes_1.510%2Bbz2-8build2_i386.deb?raw=true"
    #https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/install_ubiquity.sh?raw=true"
#https://github.com/oliveiraezequiel/foston-linux-plus/blob/main/install_ubiquity.sh
# deb http://us.archive.ubuntu.com/ubuntu/ bionic main restricted

# 
# deb http://us.archive.ubuntu.com/ubuntu/ bionic-updates main restricted
# deb http://security.ubuntu.com/ubuntu bionic-security main restricted
# 
# See http://help.ubuntu.com/community/UpgradeNotes for how to upgrade to
# newer versions of the distribution.
# deb http://us.archive.ubuntu.com/ubuntu/ bionic main restricted
# deb-src http://us.archive.ubuntu.com/ubuntu/ bionic main restricted
# 
# # Major bug fix updates produced after the final release of the
# # distribution.
# deb http://us.archive.ubuntu.com/ubuntu/ bionic-updates main restricted
# deb-src http://us.archive.ubuntu.com/ubuntu/ bionic-updates main restricted
# 
# # N.B. software from this repository is ENTIRELY UNSUPPORTED by the Ubuntu
# # team. Also, please note that software in universe WILL NOT receive any
# # review or updates from the Ubuntu security team.
# deb http://us.archive.ubuntu.com/ubuntu/ bionic universe
# deb-src http://us.archive.ubuntu.com/ubuntu/ bionic universe
# deb http://us.archive.ubuntu.com/ubuntu/ bionic-updates universe
# deb-src http://us.archive.ubuntu.com/ubuntu/ bionic-updates universe
# 
# # N.B. software from this repository is ENTIRELY UNSUPPORTED by the Ubuntu 
# # team, and may not be under a free licence. Please satisfy yourself as to 
# # your rights to use the software. Also, please note that software in 
# # multiverse WILL NOT receive any review or updates from the Ubuntu
# # security team.
# deb http://us.archive.ubuntu.com/ubuntu/ bionic multiverse
# deb-src http://us.archive.ubuntu.com/ubuntu/ bionic multiverse
# deb http://us.archive.ubuntu.com/ubuntu/ bionic-updates multiverse
# deb-src http://us.archive.ubuntu.com/ubuntu/ bionic-updates multiverse
# 
# # N.B. software from this repository may not have been tested as
# # extensively as that contained in the main release, although it includes
# # newer versions of some applications which may provide useful features.
# # Also, please note that software in backports WILL NOT receive any review
# # or updates from the Ubuntu security team.
# deb http://us.archive.ubuntu.com/ubuntu/ bionic-backports main restricted universe multiverse
# deb-src http://us.archive.ubuntu.com/ubuntu/ bionic-backports main restricted universe multiverse
# 
# # Uncomment the following two lines to add software from Canonical's
# # 'partner' repository.
# # This software is not part of Ubuntu, but is offered by Canonical and the
# # respective vendors as a service to Ubuntu users.
# deb http://archive.canonical.com/ubuntu bionic partner
# deb-src http://archive.canonical.com/ubuntu bionic partner
# 
# deb http://security.ubuntu.com/ubuntu bionic-security main restricted
# deb-src http://security.ubuntu.com/ubuntu bionic-security main restricted
# deb http://security.ubuntu.com/ubuntu bionic-security universe
# deb-src http://security.ubuntu.com/ubuntu bionic-security universe
# deb http://security.ubuntu.com/ubuntu bionic-security multiverse
# deb-src http://security.ubuntu.com/ubuntu bionic-security multiverse
# deb [trusted=yes] http://packages.bodhilinux.com/bodhi bionic b5main
# Bodhi Linux 5.x Repository (18.04 - bionic)
# deb [trusted=yes] file:/cdrom/dists/ ./ # ISO repo - BB

# deb cdrom:[edxos-plus 2024.04.25 _edxos-plus-Custom_ (20240425)]/dists/ /

# See http://help.ubuntu.com/community/UpgradeNotes for how to upgrade to
# newer versions of the distribution.
deb http://br.archive.ubuntu.com/ubuntu/ bionic main restricted
# deb-src http://br.archive.ubuntu.com/ubuntu/ bionic main restricted

## Major bug fix updates produced after the final release of the
## distribution.
deb http://br.archive.ubuntu.com/ubuntu/ bionic-updates main restricted
# deb-src http://br.archive.ubuntu.com/ubuntu/ bionic-updates main restricted

## N.B. software from this repository is ENTIRELY UNSUPPORTED by the Ubuntu
## team. Also, please note that software in universe WILL NOT receive any
## review or updates from the Ubuntu security team.
deb http://br.archive.ubuntu.com/ubuntu/ bionic universe
# deb-src http://br.archive.ubuntu.com/ubuntu/ bionic universe
deb http://br.archive.ubuntu.com/ubuntu/ bionic-updates universe
# deb-src http://br.archive.ubuntu.com/ubuntu/ bionic-updates universe

## N.B. software from this repository is ENTIRELY UNSUPPORTED by the Ubuntu 
## team, and may not be under a free licence. Please satisfy yourself as to 
## your rights to use the software. Also, please note that software in 
## multiverse WILL NOT receive any review or updates from the Ubuntu
## security team.
deb http://br.archive.ubuntu.com/ubuntu/ bionic multiverse
# deb-src http://br.archive.ubuntu.com/ubuntu/ bionic multiverse
deb http://br.archive.ubuntu.com/ubuntu/ bionic-updates multiverse
# deb-src http://br.archive.ubuntu.com/ubuntu/ bionic-updates multiverse

## N.B. software from this repository may not have been tested as
## extensively as that contained in the main release, although it includes
## newer versions of some applications which may provide useful features.
## Also, please note that software in backports WILL NOT receive any review
## or updates from the Ubuntu security team.
deb http://br.archive.ubuntu.com/ubuntu/ bionic-backports main restricted universe multiverse
# deb-src http://br.archive.ubuntu.com/ubuntu/ bionic-backports main restricted universe multiverse

## Uncomment the following two lines to add software from Canonical's
## 'partner' repository.
## This software is not part of Ubuntu, but is offered by Canonical and the
## respective vendors as a service to Ubuntu users.
# deb http://archive.canonical.com/ubuntu bionic partner
# deb-src http://archive.canonical.com/ubuntu bionic partner

deb http://security.ubuntu.com/ubuntu bionic-security main restricted
# deb-src http://security.ubuntu.com/ubuntu bionic-security main restricted
deb http://security.ubuntu.com/ubuntu bionic-security universe
# deb-src http://security.ubuntu.com/ubuntu bionic-security universe
deb http://security.ubuntu.com/ubuntu bionic-security multiverse
# deb-src http://security.ubuntu.com/ubuntu bionic-security multiverse

)

# Baixar todos os arquivos
for URL in "${URLS[@]}"; do
    FILENAME=$(basename $URL)
    wget -O "$WORK_DIR/$FILENAME" "$URL"
done

# Instalar pacotes .deb
for DEB in $WORK_DIR/*.deb; do
    sudo dpkg -i $DEB
done

# Executar scripts .sh
for SCRIPT in $WORK_DIR/*.sh; do
    chmod +x $SCRIPT
    sudo $SCRIPT
done

# Extração de arquivos .tar.xz
for TAR in $WORK_DIR/*.tar.xz; do
    tar -xf $TAR -C $WORK_DIR
done

# Instalar pacotes extraídos, se necessário
# Exemplo: sudo dpkg -i $WORK_DIR/extracted_package/*.deb

# Limpeza
rm -rf $WORK_DIR

echo "Atualização concluída com sucesso!"

